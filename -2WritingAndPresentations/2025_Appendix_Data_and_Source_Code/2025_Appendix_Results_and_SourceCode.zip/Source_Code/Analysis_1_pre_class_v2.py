import json
from collections import defaultdict
from sklearn.metrics import precision_recall_fscore_support
import pandas as pd
import matplotlib.pyplot as plt
import os

# SET = "dep_gcn"
# SET = "amr_gcn"
# SET = "narrative_ego_amr"
# SET = "narrative_ego_mlp"
# SET = "sentence"
# SET = "srl_anchored"
# SET = "srl_gcn_weighted"
# SET = "srl_predicate"
SET = "subsentence"


# ==== Settings ====
ERROR_FILE = f"2_results/results_{SET}/{SET}_errors_standardized.json"  # change to dep_gcn/subsentence/sentence as needed
TRAIN_LOG_FILE = f"2_results/results_{SET}/{SET}_train_log.json"
OUTPUT_DIR = f"2_results/results_{SET}/{SET}_analysis"  # change for each model

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ==== Load data ====
with open(ERROR_FILE, "r", encoding="utf-8") as f:
    errors_json = json.load(f)
    # Handle case where errors are inside a dict under 'errors'
    if isinstance(errors_json, dict) and "errors" in errors_json:
        errors = errors_json["errors"]
    else:
        errors = errors_json

# Derive class names from labels in the error file
label_set = set()
for e in errors:
    label_set.add(e["true_label"])
    label_set.add(e["pred_label"])

class_names = sorted(label_set)
label2id = {name: idx for idx, name in enumerate(class_names)}

# ==== Prepare ground truth and predictions ====
y_true = []
y_pred = []

for e in errors:
    if e["true_label"] not in label2id or e["pred_label"] not in label2id:
        continue
    y_true.append(label2id[e["true_label"]])
    y_pred.append(label2id[e["pred_label"]])

# ==== Compute per-class scores ====
precision, recall, f1, support = precision_recall_fscore_support(
    y_true, y_pred, labels=range(len(class_names)), zero_division=0
)

df = pd.DataFrame({
    "Class": class_names,
    "Support": support,
    "Precision": precision,
    "Recall": recall,
    "F1 Score": f1
}).sort_values(by="F1 Score", ascending=False)

# ==== Save CSV and plot ====
df.to_csv(os.path.join(OUTPUT_DIR, "per_class_f1.csv"), index=False)

plt.figure(figsize=(10, 6))
plt.barh(df["Class"], df["F1 Score"], color="teal")
plt.xlabel("F1 Score")
plt.title("Per-Class F1 Score")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "per_class_f1_plot.png"), dpi=300)
plt.close()

print("✅ Per-class F1 analysis completed. Results saved to:", OUTPUT_DIR)
